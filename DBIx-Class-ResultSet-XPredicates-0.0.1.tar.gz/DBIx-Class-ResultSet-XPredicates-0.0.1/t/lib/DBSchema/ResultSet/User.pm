use strict;
use warnings;

package DBSchema::ResultSet::User;

use base 'DBIx::Class::ResultSet::XPredicates';

1;
